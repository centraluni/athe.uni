# Dental-clinic
a fully responsive dynamic dental clinic website using HTML, CSS, JS, PHP and MySQL
